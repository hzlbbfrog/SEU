<?php
	header("content-type:text/html;charset=utf8");
	$link =mysqli_connect('localhost:3306','root','localhost','rock');
	if (!$link) die("连接失败");
	mysqli_set_charset($link, "utf8"); 

$keyword = isset($_GET['keyword'])?$_GET['keyword']:"";
$page = isset($_GET['page'])?$_GET['page']:1;//获取当前分页数
$mohu = isset($_GET['mohu'])?$_GET['mohu']:"";

//$leixing= isset($_GET['leixing'])?$_GET['leixing']:"";

$limitNews = 5;   //每页显示新闻数量, 这里设置每页显示3条新闻
$countNews = 0;   //总共有多少条新闻
$countPage = 0;   //一共有多少页数
$prev = ($page - 1 <= 0 )?1:$page-1;
$next = ($page + 1 > $countPage)?$countPage:$page+1;

//echo $keyword;

$limitFrom = ($page - 1) * $limitNews;//从第几条数据开始读记录
//每页显示5个
//page = l  limit 0
//page = 2  limit 3
//page = 3  limit 6
$result=""; 
  if ($keyword) {
	$sql = "select * from concrete where name like '%$keyword%' limit {$limitFrom}, {$limitNews}";
	$sqlCount = "select count(*) from concrete where name like '%$keyword%'";
//	17-Ⅰ-3-1-1-2 Ⅲ Ⅱ Ⅳ
//	$sql = "select * from concrete where database1 like '%-Ⅰ-3-1-1-_'limit {$limitFrom}, {$limitNews}";
//	$sqlCount = "select count(*) from concrete where database1 like '%-Ⅰ-3-1-1-_'";
	
	$retQuery = mysqli_query($link, $sqlCount); //查询数量sql语句
	$retCount = mysqli_fetch_array($retQuery);  //获取数量
	$count = $retCount[0]?$retCount[0]:0;  //判断获取的新闻数量
	$countNews = $count;
	
	$countPage = $countNews%$limitNews;  //求余数获取分页数量能否被除尽
	if(($countPage) > 0) {  //获取的页数有余
	 $countPage = ceil($countNews/$limitNews);
	 // ceil()函数向上舍入为最接近的整数,除不尽则取整数+1页, 10个新闻每个页面显示3个，成3个页面，剩余1个成1个页面
	} else {
	 $countPage = $countNews/$limitNews;
	}
	
	$prev = ($page - 1 <= 0 )?1:$page-1;
	$next = ($page + 1 > $countPage)?$countPage:$page+1;
	
	$result = mysqli_query($link, $sql);
 } else{
// 	$mohu = isset($_GET['mohu'])?$_GET['mohu']:"";
 	if (!$mohu) {
			 	$bianhao = isset($_GET['bianhao'])?$_GET['bianhao']:""; 
			 	$zuhao = isset($_GET['zuhao'])?$_GET['zuhao']:"";
			 	$shikuai = isset($_GET['shikuai'])?$_GET['shikuai']:"";
			 	$leixing = isset($_GET['leixing'])?$_GET['leixing']:"";
			 	$fangfa = isset($_GET['fangfa'])?$_GET['fangfa']:""; 
			 	$kangjian = isset($_GET['kangjian'])?$_GET['kangjian']:"";
			 	
			 	$mohu="";
			 	if (!$bianhao) $mohu=$mohu."%-" ;else $mohu=$mohu.$bianhao."-";
			 	if (!$leixing) $mohu=$mohu."_-"; else $mohu=$mohu.$leixing."-";
			 	if (!$fangfa) $mohu=$mohu."_-"; else $mohu=$mohu.$fangfa."-";
			 	if (!$zuhao) $mohu=$mohu."_-"; else $mohu=$mohu.$zuhao."-";
			 	if (!$kangjian) $mohu=$mohu."_-"; else $mohu=$mohu.$kangjian."-";
			 	if (!$shikuai) $mohu=$mohu."_"; else $mohu=$mohu.$shikuai;
 	}
 	
 	echo $mohu;
 	if ($mohu!="%-_-_-_-_-_"){
		 	$sql = "select * from concrete where database1 like '$mohu'limit {$limitFrom}, {$limitNews}";
			$sqlCount = "select count(*) from concrete where database1 like '$mohu'";
			
			$retQuery = mysqli_query($link, $sqlCount); //查询数量sql语句
			$retCount = mysqli_fetch_array($retQuery);  //获取数量
			$count = $retCount[0]?$retCount[0]:0;  //判断获取的新闻数量
			$countNews = $count;
			
			$countPage = $countNews%$limitNews;  //求余数获取分页数量能否被除尽
			if(($countPage) > 0) {  //获取的页数有余
			 $countPage = ceil($countNews/$limitNews);
			 // ceil()函数向上舍入为最接近的整数,除不尽则取整数+1页, 10个新闻每个页面显示3个，成3个页面，剩余1个成1个页面
			} else {
			 $countPage = $countNews/$limitNews;
			}
			
			$prev = ($page - 1 <= 0 )?1:$page-1;
			$next = ($page + 1 > $countPage)?$countPage:$page+1;
			
			$result = mysqli_query($link, $sql);
 	}
	
 }
  	mysqli_close($link);	
?>

<!DOCTYPE html>
<html lang="zh-cn">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta name="renderer" content="webkit">
<title></title>
<link rel="stylesheet" href="css/pintuer.css">
<link rel="stylesheet" href="css/admin.css">
	<link href="umeditorphp/themes/default/css/umeditor.css" type="text/css" rel="stylesheet">
		
	<script type="text/javascript" src="umeditorphp/third-party/jquery.min.js"></script>
    <script type="text/javascript" charset="utf-8" src="umeditorphp/umeditor.config.js"></script>
    <script type="text/javascript" charset="utf-8" src="umeditorphp/umeditor.min.js"></script>
    <script type="text/javascript" charset="utf-8" src="umeditorphp/umeditor.js"></script>
    <script type="text/javascript" src="umeditorphp/lang/zh-cn/zh-cn.js"></script>
	<script src="js/jquery.js"></script>
	<script src="js/pintuer.js"></script>
</head>

<body>
<div class="panel admin-panel margin-top" id="add">	
	<div class="panel-head"><strong><span class="icon-pencil-square-o"></span> 按工程名称检索</strong></div>
	<div class="body-content">
	  <form method="get" class="form-x" action="concrete.php" style="text-align: center;">  
	  	   
	      <div class="form-group" >
	      	<div class="label" style="margin-left: 30px;">
          	<label>请输入工程名称：</label>
       		</div>
	      	<div class="field">
	      		<input type="text" class="input w53" name="keyword" value="<?php echo $keyword;?>"  data-validate="required:请输入搜索内容"/>
	      	</div>
	      </div>
	      
	      <div class="form-group">
		        <div class="label">
		          <label></label>
		        </div>
		        <div class="field">
		          <button class="button bg-main icon-check-square-o" type="submit" onclick="window.location.href='#add1'"> 搜索</button>
		        </div>
      	  </div>
       </form> 
	</div>
</div>		

<div class="panel admin-panel margin-top" >	
	<div class="panel-head"><strong><span class="icon-pencil-square-o"></span>按数据库统一编号模糊检索</strong></div>
	<div class="body-content">
	  <form method="get" class="form-x" action="concrete.php" style="text-align: center;">  
	  	   
	      <div class="form-group" >
	      	<div class="label" >
          	<label>工程编号：</label>
       		</div>
	      	<div class="field">
	      		<input type="text" class="input w50" name="bianhao" placeholder="水库或水电站的编号"/>
	      	</div>
	      </div>
	      
	      <div class="form-group" >
	      	<div class="label" >
          	<label>试验组号：</label>
       		</div>
	      	<div class="field">
	      		<input type="text" class="input w50" name="zuhao" placeholder="该试件所在组数"/>
	      	</div>
	      </div>
	      
	      <div class="form-group" >
	      	<div class="label" >
          	<label>试块号：</label>
       		</div>
	      	<div class="field">
	      		<input type="text" class="input w50" name="shikuai" placeholder="某组试块中某一具体试块编号"/>
	      	</div>
	      </div>
	      
	      <div class="form-group" >
	      	<div style="margin-left: 30px;">
          	剪切面类型：
          	<input type="checkbox" name="leixing" value="Ⅰ">Ⅰ 胶结面类
	      			<input type="checkbox" name="leixing" value="Ⅱ">Ⅱ 软弱结构面类
	      				<input type="checkbox" name="leixing" value="Ⅲ">Ⅲ 节理裂隙及层面类
	      					<input type="checkbox" name="leixing" value="Ⅳ">Ⅳ 岩体本身
         	</div>
	      </div>
	      
	      <div class="form-group">
	      	试验方法：
	      		<input type="checkbox" name="fangfa" value="1">1 单点平推法
	      			<input type="checkbox" name="fangfa" value="2">2 单点斜推法
	      				<input type="checkbox" name="fangfa" value="3">3 多点平推法
	      					<input type="checkbox" name="fangfa" value="4">4 多点斜推法
	      </div>
	      
	      <div class="form-group">
	      	抗剪强度类型：
	      		<input type="checkbox" name="kangjian" value="1">1 抗剪断值
	      			<input type="checkbox" name="kangjian" value="2">2 抗剪值
	      				<input type="checkbox" name="kangjian" value="3">3 屈服值
	      </div>
	      
	      <div class="form-group">
		        <div class="label">
		          <label></label>
		        </div>
		        <div class="field">
		          <button class="button border-main icon-search" type="submit" > 搜索</button>
		        </div>
      	  </div>
       </form> 
	</div>
</div>
	
	<p></p>
	
<div class="panel admin-panel" id="add1">
  <div class="panel-head" ><strong class="icon-reorder" > 内容列表</strong></div>
  
  <table class="table table-hover text-center">
    <tr>
      <th width="10%">数据库统一名称</th>
      <th width="8%">工程名称</th>
      <th width="8%">试件编号</th>
      <th width="7%">试验岩体名称</th>
      <th width="5%">正应力(Mpa)</th>
      <th width="5%">剪应力(Mpa)</th>
      <th width="8%">试验方法</th>
      <th width="5%">混凝土标号</th>
      <th width="15%">剪面特征</th>
      <th width="34%">数据来源</th>
    </tr>
	<?php?>

	<?php
	 
    if ($result) {
     		while($row=mysqli_fetch_array($result)) {
//	while ($row=mysqli_fetch_array($result1,MYSQLI_ASSOC)){
	?>   
   	<tr>
      <td><?php echo $row['database1'];?></td>     
      <!--<td><?php echo $row['url'];?></td>-->
      <!--<td><img src="maps/111.gif" alt="" width="120" height="50" /></td>-->
      
      <td><?php echo $row['name'];?></td>
      <!--<td><?php echo $row['author'];?></td>-->
      <!--<td><?php echo htmlspecialchars_decode($row['content']);?></td>-->
       <!--<td><?php echo $row['content'];?></td>-->
      <td><?php echo $row['COL 3'];?></td>
      <td><?php echo $row['COL 4'];?></td>
      
      <td><?php echo $row['COL 9'];?></td>
      <td><?php echo $row['COL 10'];?></td>
      
  <!--    <td><?php echo $row['COL 5'];?></td>-->
      <td><?php echo $row['COL 6'];?></td>
      <td><?php echo $row['COL 7'];?></td>
      <td><?php echo $row['COL 13'];?></td>
      <td><?php echo $row['COL 14'];?></td>
      <!--<td><div class="button-group">
      <a class="button border-main" href="#add"><span class="icon-edit"></span> 修改</a>
      <a class="button border-red" href="javascript:void(0)" onclick="return del(1,1)"><span class="icon-trash-o"></span> 删除</a>
      </div></td>-->
    </tr>

    <?php
    				}
    	}
    ?>
    
    <!--$bianhao = isset($_GET['bianhao'])?$_GET['bianhao']:""; 
 	$zuhao = isset($_GET['zuhao'])?$_GET['zuhao']:"";
 	$shikuai = isset($_GET['shikuai'])?$_GET['shikuai']:"";
 	$leixing = isset($_GET['leixing'])?$_GET['leixing']:"";
 	$fangfa = isset($_GET['fangfa'])?$_GET['fangfa']:""; 
 	$kangjian-->
    
 	<tr>
      <td colspan="8">
      	<div class="pagelist"> 
      		<!--href="?page=<?php echo $prev;?>&keyword=<?php echo $keyword;?>&bianhao=<?php echo $bianhao;?>&zuhao=<?php echo $zuhao;?>&shikuai=<?php echo $shikuai;?>&leixing=<?php echo $leixing;?>&fangfa=<?php echo $fangfa;?>"-->
      	<a href="?page=<?php echo $prev;?>&mohu=<?php echo $mohu;?>&keyword=<?php echo $keyword;?>">上一页</a> 
      	
      	<?php for($i=1; $i<=$countPage; $i++):?>
      		<!--<span class="current">-->
      			<?php
      				if ($i==$page) {
      				?>
      				<!--<span  class="current">-->
      					<a class="current" href="?page=<?php echo $i;?>&mohu=<?php echo $mohu;?>&keyword=<?php echo $keyword;?>"><?php echo $i;?></a>
      				<!--</span>-->
     			<?php  }else {  ?>
     		   <a href="?page=<?php echo $i;?>&mohu=<?php echo $mohu;?>&keyword=<?php echo $keyword;?>"><?php echo $i;?></a>
     		   <?php  }  ?>
   		<?php endfor;?>
   			
      	<!--<span class="current">1</span>-->
      	<!--<a href="">2</a>
      	<a href="">3</a>-->
      	<a href="?page=<?php echo $next;?>&mohu=<?php echo $mohu;?>&keyword=<?php echo $keyword;?>">下一页</a>
      	<a href="?page=<?php echo $countPage;?>&mohu=<?php echo $mohu;?>&keyword=<?php echo $keyword;?>">尾页</a> 
      	</div>
      	
      </td>
    </tr>
   
    
   
  </table>
</div>

<script type="text/javascript">
function del(id,mid){
	if(confirm("您确定要删除吗?")){
	
	}
}
</script>

<!--<div class="panel admin-panel margin-top" id="add">
  <div class="panel-head"><strong><span class="icon-pencil-square-o"></span> 增加内容</strong></div>
  <div class="body-content">
    <form method="post" class="form-x" action="xuexiaop.php">     
      <div class="form-group">
        <div class="label">
          <label>标题：</label>
        </div>
        <div class="field">
          <input type="text" class="input w50" value="" name="title" data-validate="required:请输入标题" />
          <div class="tips"></div>
        </div>
      </div>
      
      <div class="form-group">
        <div class="label">
          <label></label>
        </div>
        <div class="field">
          <button class="button bg-main icon-check-square-o" type="submit"> 提交</button>
        </div>
      </div>
      
    </form>
    
  </div>
</div>-->

</body>
</html>