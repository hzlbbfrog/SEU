<?php
	header("content-type:text/html;charset=utf8");
	$link =mysqli_connect('localhost:3306','root','localhost','news');
	if (!$link) die("连接失败");
	mysqli_set_charset($link, "utf8");
	
	$result1 = mysqli_query($link, 'SELECT * FROM lunbo');
	
 	$arr1=mysqli_fetch_all($result1,MYSQLI_ASSOC);//从结果集中取得所有行作为关联数组：
    //mysql_fetch_array()函数从结果集中取得一行作为关联数组，或数字数组，或二者兼有
	
 	 //echo 可以内置html标签。HTML标签里也可以内置PHP。
 	print_r($arr1);
	echo count($arr1,0); // 不统计多维数组的，相当于只统计第一维。
//	$row=mysqli_fetch_array($result1,MYSQLI_ASSOC); 这个与all函数不能同时使用。
//  我觉得如果再获取一次result1，应该就能重复使用了。
    
//	print_r ($row);
//	while ($row=mysqli_fetch_array($result1,MYSQLI_ASSOC)){
//		echo $row['id'];
//		echo "<br>";
//	}
// 	$id=1;
// 	$arr2=json_encode($arr1,JSON_UNESCAPED_UNICODE);
// 	echo "<script> arr=$arr2;
// 		  </script>";
//	echo $arr2; 
  	mysqli_close($link);	
?>

<!DOCTYPE html>
<html>
	<head>
	 <!--123-->
	</head>
	<body>
	  <div>
	  	<img src="<?php echo "maps/".$arr1[4]['url'] ; 
	  				?>" />
	  	<img src="../phpfirst/img/rediansy"  />
	  	<!--上面是图片在本文件加中的。
	  	下面是图片在临近的文件夹中的。。-->
	  	<!--<?php
	  		echo $arr1[4]['url'];
	  		?>  html语言嵌套PHP语言--> 
	  </div>
	</body>

</html>
