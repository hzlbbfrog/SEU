<?php
	header("content-type:text/html;charset=utf8");
	$link =mysqli_connect('localhost:3306','root','localhost','rock');
	if (!$link) die("连接失败");
	mysqli_set_charset($link, "utf8"); 

//	$result1 = mysqli_query($link, 'SELECT * FROM xuexiao');
$keyword = isset($_GET['keyword'])?$_GET['keyword']:"";
$page = isset($_GET['page'])?$_GET['page']:1;//获取当前分页数
$limitNews = 5;   //每页显示新闻数量, 这里设置每页显示3条新闻
$countNews = 0;   //总共有多少条新闻
$countPage = 0;   //一共有多少页数
$prev = ($page - 1 <= 0 )?1:$page-1;
$next = ($page + 1 > $countPage)?$countPage:$page+1;

//echo $keyword;

$limitFrom = ($page - 1) * $limitNews;//从第几条数据开始读记录
//每页显示5个
//page = l  limit 0
//page = 2  limit 3
//page = 3  limit 6
$result=""; 
  if ($keyword) {
  	$sql = "select * from weak where name like '%$keyword%' limit {$limitFrom}, {$limitNews}";
	$sqlCount = "select count(*) from weak where name like '%$keyword%'";
	$retQuery = mysqli_query($link, $sqlCount); //查询数量sql语句
	$retCount = mysqli_fetch_array($retQuery);  //获取数量
	$count = $retCount[0]?$retCount[0]:0;  //判断获取的新闻数量
	$countNews = $count;
	
	$countPage = $countNews%$limitNews;  //求余数获取分页数量能否被除尽
	if(($countPage) > 0) {  //获取的页数有余
	 $countPage = ceil($countNews/$limitNews);
	 // ceil()函数向上舍入为最接近的整数,除不尽则取整数+1页, 10个新闻每个页面显示3个，成3个页面，剩余1个成1个页面
	} else {
	 $countPage = $countNews/$limitNews;
	}
	
	$prev = ($page - 1 <= 0 )?1:$page-1;
	$next = ($page + 1 > $countPage)?$countPage:$page+1;
	
	$result = mysqli_query($link, $sql);
  }
  	mysqli_close($link);	
?>

<!DOCTYPE html>
<html lang="zh-cn">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta name="renderer" content="webkit">
<title></title>
<link rel="stylesheet" href="css/pintuer.css">
<link rel="stylesheet" href="css/admin.css">
	<link href="umeditorphp/themes/default/css/umeditor.css" type="text/css" rel="stylesheet">
		
	<script type="text/javascript" src="umeditorphp/third-party/jquery.min.js"></script>
    <script type="text/javascript" charset="utf-8" src="umeditorphp/umeditor.config.js"></script>
    <script type="text/javascript" charset="utf-8" src="umeditorphp/umeditor.min.js"></script>
    <script type="text/javascript" charset="utf-8" src="umeditorphp/umeditor.js"></script>
    <script type="text/javascript" src="umeditorphp/lang/zh-cn/zh-cn.js"></script>
<!--<script src="js/jquery.js"></script>-->
	<script src="js/pintuer.js"></script>
</head>

<body>
<div class="panel admin-panel margin-top" id="add">	
	<div class="panel-head"><strong><span class="icon-pencil-square-o"></span> 检索信息</strong></div>
	<div class="body-content">
	  <form method="get" class="form-x" action="weak.php" style="text-align: center;">  
	  	   
	      <div class="form-group" >
	      	<div class="label" style="margin-left: 30px;">
          	<label>请输入搜索内容：</label>
       		</div>
	      	<div class="field">
	      		<input type="text" class="input w53" name="keyword" value="<?php echo $keyword;?>"  data-validate="required:请输入搜索内容"/>
	      	</div>
	      </div>
	      
	      <div class="form-group">
		        <div class="label">
		          <label></label>
		        </div>
		        <div class="field">
		          <button class="button bg-main icon-check-square-o" type="submit"> 搜索</button>
		        </div>
      	  </div>
        </form> 
      
	</div>
	
	<!--<div class="panel-head"><strong><span class="icon-pencil-square-o"></span> 增加内容</strong></div>-->
	<!--<button type="button" class="button border-yellow" onclick="window.location.href='#add'"><span class="icon-plus-square-o"></span> 搜索</button>-->
</div>	
	
	<p></p>
	
<div class="panel admin-panel">
  <div class="panel-head"><strong class="icon-reorder"> 内容列表</strong></div>
  
  <table class="table table-hover text-center">
    <tr>
      <th width="10%">数据库统一名称</th>
      <th width="8%">工程名称</th>
      <th width="8%">试件编号</th>
      <th width="7%">试验岩体名称</th>
      <th width="5%">试件尺寸</th>
      <th width="8%">试验方法</th>
      <th width="5%">抗剪类型</th>
      <th width="15%">剪面特征</th>
      <th width="34%">数据来源</th>
    </tr>
	<?php?>

	<?php
	 
    if ($result) {
     		while($row=mysqli_fetch_array($result)) {
//	while ($row=mysqli_fetch_array($result1,MYSQLI_ASSOC)){
	?>   
   	<tr>
      <td><?php echo $row['COL 1'];?></td>         
      <td><?php echo $row['name'];?></td>
      <td><?php echo $row['COL 3'];?></td>
      <td><?php echo $row['COL 4'];?></td>
      <td><?php echo $row['COL 5'];?></td>
      <td><?php echo $row['COL 6'];?></td>
      <td><?php echo $row['COL 11'];?></td>
      <td><?php echo $row['COL 13'];?></td>
      <td><?php echo $row['COL 14'];?></td>
      <!--<td><div class="button-group">
      <a class="button border-main" href="#add"><span class="icon-edit"></span> 修改</a>
      <a class="button border-red" href="javascript:void(0)" onclick="return del(1,1)"><span class="icon-trash-o"></span> 删除</a>
      </div></td>-->
    </tr>

    <?php
    				}
    	}
    ?>
    
 	<tr>
      <td colspan="8">
      	<div class="pagelist"> 
      		
      	<a href="?page=<?php echo $prev;?>&keyword=<?php echo $keyword;?>">上一页</a> 
      	
      	<?php for($i=1; $i<=$countPage; $i++):?>
      		<!--<span class="current">-->
      			<?php
      				if ($i==$page) {
      				?>
      				<!--<span  class="current">-->
      					<a class="current" href="?page=<?php echo $i;?>&keyword=<?php echo $keyword;?>"><?php echo $i;?></a>
      				<!--</span>-->
     			<?php  }else {  ?>
     		   <a href="?page=<?php echo $i;?>&keyword=<?php echo $keyword;?>"><?php echo $i;?></a>
     		   <?php  }  ?>
   		<?php endfor;?>
   			
      	<!--<span class="current">1</span>-->
      	<!--<a href="">2</a>
      	<a href="">3</a>-->
      	<a href="?page=<?php echo $next;?>&keyword=<?php echo $keyword;?>">下一页</a>
      	<a href="?page=<?php echo $countPage;?>&keyword=<?php echo $keyword;?>">尾页</a> 
      	</div>
      	
      </td>
    </tr>
    
   
  </table>
</div>

<script type="text/javascript">
function del(id,mid){
	if(confirm("您确定要删除吗?")){
	
	}
}
</script>

<!--<div class="panel admin-panel margin-top" id="add">
  <div class="panel-head"><strong><span class="icon-pencil-square-o"></span> 增加内容</strong></div>
  <div class="body-content">
    <form method="post" class="form-x" action="xuexiaop.php">     
      <div class="form-group">
        <div class="label">
          <label>标题：</label>
        </div>
        <div class="field">
          <input type="text" class="input w50" value="" name="title" data-validate="required:请输入标题" />
          <div class="tips"></div>
        </div>
      </div>
      
      <div class="form-group">
        <div class="label">
          <label></label>
        </div>
        <div class="field">
          <button class="button bg-main icon-check-square-o" type="submit"> 提交</button>
        </div>
      </div>
      
    </form>
    
  </div>
</div>-->

</body>
</html>