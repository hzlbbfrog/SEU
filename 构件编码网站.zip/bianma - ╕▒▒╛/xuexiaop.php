<?php
	header("content-type:text/html;charset=utf8");
	$link =mysqli_connect('localhost:3306','root','localhost','news');
	if (!$link) die("连接失败"); 
//	echo "lianjie";
	mysqli_set_charset($link, "utf8");
	// 标题 作者 url 图片 内容
	$title = isset($_POST['title']) ? $_POST['title'] : ""; 
	$author = isset($_POST['author']) ? $_POST['author'] : ""; 
	$url = isset($_POST['url']) ? $_POST['url'] : "";
//	$content = isset($_POST['content']) ? $_POST['content'] : "";
	$map = isset($_POST['map']) ? $_POST['map'] : "";
	$date = isset($_POST['date']) ? $_POST['date'] : ""; 
	$flag = isset($_POST['flag']) ? $_POST['flag'] : "";
	
	$content = isset($_POST['myEditor']) ? $_POST['myEditor'] : "";
//	$content =  htmlspecialchars($content);
//	echo $content;
//	if ($flag1=="") $flag=0;
//	else $flag=1 ; // flag表示 如果图片有新页面，则flag=1,否则为空。
	if ($url) {
//		$sql="insert into lunbo(url,flag,title,author,content) values('$url','$flag','$title','$author','$content')";
		$sql="insert into xuexiao(url,flag,title,author,content,date,map) values('$url','$flag','$title','$author','$content','$date','$map')";
		$result=mysqli_query($link,$sql);
			if ($result) {
				echo "<script> alert('发布成功');window.location.href='xuexiao.php'</script>";
			}else {
				echo "<script> alert('发布失败');</script>";
			}
		}
	
	mysqli_close($link);	 	
?>