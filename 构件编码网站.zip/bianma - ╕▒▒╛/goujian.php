<?php
	header("content-type:text/html;charset=utf8");
	$link =mysqli_connect('localhost:3306','root','localhost','bianma');
	if (!$link) die("连接失败");
	mysqli_set_charset($link, "utf8"); 

//	$result1 = mysqli_query($link, 'SELECT * FROM xuexiao');
$keyword = isset($_GET['keyword'])?$_GET['keyword']:"";
$page = isset($_GET['page'])?$_GET['page']:1;//获取当前分页数
$limitNews = 5;   //每页显示新闻数量, 这里设置每页显示3条新闻
$countNews = 0;   //总共有多少条新闻
$countPage = 0;   //一共有多少页数
$prev = ($page - 1 <= 0 )?1:$page-1;
$next = ($page + 1 > $countPage)?$countPage:$page+1;

//echo $keyword;

$limitFrom = ($page - 1) * $limitNews;//从第几条数据开始读记录
//每页显示5个
//page = l  limit 0
//page = 2  limit 3
//page = 3  limit 6
$result=""; 
//echo $keyword;
  if ($keyword) {
  	$sql = "select * from goujian where ma = '$keyword' or ming = '$keyword' limit {$limitFrom}, {$limitNews}";
	$sqlCount = "select count(*) from goujian where ma = '$keyword' or ming = '$keyword'";
	$retQuery = mysqli_query($link, $sqlCount); //查询数量sql语句
	$retCount = mysqli_fetch_array($retQuery);  //获取数量
	$count = $retCount[0]?$retCount[0]:0;  //判断获取的新闻数量
	$countNews = $count;
	
	$countPage = $countNews%$limitNews;  //求余数获取分页数量能否被除尽
	if(($countPage) > 0) {  //获取的页数有余
	 $countPage = ceil($countNews/$limitNews);
	 // ceil()函数向上舍入为最接近的整数,除不尽则取整数+1页, 10个新闻每个页面显示3个，成3个页面，剩余1个成1个页面
	} else {
	 $countPage = $countNews/$limitNews;
	}
	
	$prev = ($page - 1 <= 0 )?1:$page-1;
	$next = ($page + 1 > $countPage)?$countPage:$page+1;
	
	$result = mysqli_query($link, $sql);

  }
//	mysqli_close($link);	
?>

<!DOCTYPE html>
<html lang="zh-cn">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta name="renderer" content="webkit">
<title></title>
<link rel="stylesheet" href="css/pintuer.css">
<link rel="stylesheet" href="css/admin.css">
	<link href="umeditorphp/themes/default/css/umeditor.css" type="text/css" rel="stylesheet">
		
	<script type="text/javascript" src="umeditorphp/third-party/jquery.min.js"></script>
    <script type="text/javascript" charset="utf-8" src="umeditorphp/umeditor.config.js"></script>
    <script type="text/javascript" charset="utf-8" src="umeditorphp/umeditor.min.js"></script>
    <script type="text/javascript" charset="utf-8" src="umeditorphp/umeditor.js"></script>
    <script type="text/javascript" src="umeditorphp/lang/zh-cn/zh-cn.js"></script>
<!--<script src="js/jquery.js"></script>-->
	<script src="js/pintuer.js"></script>
</head>

<body>
<div class="panel admin-panel margin-top" id="add">	
	<div class="panel-head"><strong><span class="icon-pencil-square-o"></span> 检索信息</strong></div>
	<div class="body-content">
	  
	  <!--很重要-->
	  <form method="get" class="form-x" action="goujian.php" style="text-align: center;">  
	  	   
	      <div class="form-group" >
	      	<div class="label" style="margin-left: 30px;">
          	<label>请输入搜索内容：</label>
       		</div>
	      	<div class="field">
	      		<input type="text" class="input w53" name="keyword" value="<?php echo $keyword;?>"  data-validate="required:请输入搜索内容"/>
	      	</div>
	      </div>
	      
	      <div class="form-group">
		        <div class="label">
		          <label></label>
		        </div>
		        <div class="field">
		          <button class="button bg-main icon-check-square-o" type="submit"> 搜索</button>
		        </div>
      	  </div>
        </form> 
      
	</div>
	
	<!--<div class="panel-head"><strong><span class="icon-pencil-square-o"></span> 增加内容</strong></div>-->
	<!--<button type="button" class="button border-yellow" onclick="window.location.href='#add'"><span class="icon-plus-square-o"></span> 搜索</button>-->
</div>	
	
	
	
	<p></p>
	
	



	<p></p>
	
	
	<div class="panel admin-panel" id="add1">
  <div class="panel-head"><strong class="icon-reorder">构件图片</strong></div>
  
  <table class="table table-hover text-center">
    <tr>
      <th width="50%">二维码</th>
      <th width="50%">构件图1</th>
    </tr>
   
	<?php?>
    <?php
	$sql = "select * from goujian where ma = '$keyword' or ming = '$keyword' limit {$limitFrom}, {$limitNews}";
	$result = mysqli_query($link, $sql);  
    if ($result) {
     		while($row=mysqli_fetch_array($result)) {
//	while ($row=mysqli_fetch_array($result1,MYSQLI_ASSOC)){
	?>  
	 
	<!--<tr class="table" style="font-size: 100px;">
      <th width="10%"><?php echo $row['ma'];?></th>         
      <th width="8%"><?php echo $row['ming'];?></th> 
      <th width="15%"><?php echo $row['cailiao'];?></th> 
      <th width="8%"><?php echo $row['dengji'];?></th> 
      <th width="7%"><?php echo $row['qiangdu'];?></th> 
      <th width="5%"><?php echo $row['yuyingli'];?></th> 
      <th width="8%"><?php echo $row['yumaijian'];?></th> 
      <th width="5%"><?php echo $row['wenjian'];?></th> 
      <th width="34%"><?php echo $row['biaozhun'];?></th> 
    </tr>-->
   	<tr style="font-size: 15px;">
      <td><img style="width: 30%;" src="<?php echo $row['renyuan'];?>" /></td>         
      <td><img  style="width: 66%;" src="<?php echo $row['weixiuqi'];?>" /> </td>
      <!--<td><?php echo $row['cailiao'];?></td>
      <td><?php echo $row['dengji'];?></td>
      <td><?php echo $row['qiangdu'];?></td>
      <td><?php echo $row['yuyingli'];?></td>
      <td><?php echo $row['yumaijian'];?></td>
      <td><?php echo $row['wenjian'];?></td>
      <td><?php echo $row['biaozhun'];?></td>-->
    </tr>
    
    
    
    
        <!--<tr>
    	<th width="50%"> <img  style="width: 10%;" src="<?php echo $row['renyuan'];?>" /> </th>
    	<th width="50%"> <img  style="width: 40%;" src="<?php echo $row['weixiuqi'];?>" /> </th>
    </tr>-->
    <!--<img  style="width: 10%;" src="<?php echo $row['renyuan'];?>" />
    <img  style="width: 40%;" src="<?php echo $row['weixiuqi'];?>" />-->
    
         <?php
    				}
    } 
    ?>   
    </table>
    


    
    <tr> 
      <td colspan="8">
      	<div class="pagelist"> 
      		
      	<a href="?page=<?php echo $prev;?>&keyword=<?php echo $keyword;?>">上一页</a> 
      	
      	<?php for($i=1; $i<=$countPage; $i++):?>
      		<!--<span class="current">-->
      			<?php
      				if ($i==$page) {
      				?>
      				<!--<span  class="current">-->
      					<a class="current" href="?page=<?php echo $i;?>&keyword=<?php echo $keyword;?>"><?php echo $i;?></a>
      				<!--</span>-->
     			<?php  }else {  ?>
     		   <a href="?page=<?php echo $i;?>&keyword=<?php echo $keyword;?>"><?php echo $i;?></a>
     		   <?php  }  ?>
   		<?php endfor;?>
   			
      	<a href="?page=<?php echo $next;?>&keyword=<?php echo $keyword;?>">下一页</a>
      	<a href="?page=<?php echo $countPage;?>&keyword=<?php echo $keyword;?>">尾页</a> 
      	</div>
      	
      	
      	  </td>
    </tr>
    	
     </div>  
	
	<p></p>
	
	
<div class="panel admin-panel" id="add1">
  <div class="panel-head"><strong class="icon-reorder">设计生产部分</strong></div>
  
  <table class="table table-hover text-center">
    <tr>
      <th width="10%">构件编码</th>
      <th width="10%">构件名</th>
      <th width="15%">构件材料</th>
      <th width="8%">材料等级</th>
      <th width="14%">强度设计值</th>
      <th width="5%">有无预应力</th>
      <th width="8%">预埋件</th>
      <th width="15%">文件</th>
      <th width="15%">相关标准</th>
    </tr>
   
	<?php?>

	<?php
	$sql = "select * from goujian where ma = '$keyword' or ming = '$keyword' limit {$limitFrom}, {$limitNews}";
	$result = mysqli_query($link, $sql);  
    if ($result) {
     		while($row=mysqli_fetch_array($result)) {
//	while ($row=mysqli_fetch_array($result1,MYSQLI_ASSOC)){
	?>   
	<!--<tr class="table" style="font-size: 100px;">
      <th width="10%"><?php echo $row['ma'];?></th>         
      <th width="8%"><?php echo $row['ming'];?></th> 
      <th width="15%"><?php echo $row['cailiao'];?></th> 
      <th width="8%"><?php echo $row['dengji'];?></th> 
      <th width="7%"><?php echo $row['qiangdu'];?></th> 
      <th width="5%"><?php echo $row['yuyingli'];?></th> 
      <th width="8%"><?php echo $row['yumaijian'];?></th> 
      <th width="5%"><?php echo $row['wenjian'];?></th> 
      <th width="34%"><?php echo $row['biaozhun'];?></th> 
    </tr>-->
   	<tr style="font-size: 15px;">
      <td><?php echo $row['ma'];?></td>         
      <td><?php echo $row['ming'];?></td>
      <td><?php echo $row['cailiao'];?></td>
      <td><?php echo $row['dengji'];?></td>
      <td><?php echo $row['qiangdu'];?></td>
      <td><?php echo $row['yuyingli'];?></td>
      <td><?php echo $row['yumaijian'];?></td>
      <td><?php echo $row['wenjian'];?></td>
      <td><?php echo $row['biaozhun'];?></td>
    </tr>
    <?php
    				}
    	}
    ?>
    </table>
    
    <tr> 
      <td colspan="8">
      	<div class="pagelist"> 
      		
      	<a href="?page=<?php echo $prev;?>&keyword=<?php echo $keyword;?>">上一页</a> 
      	
      	<?php for($i=1; $i<=$countPage; $i++):?>
      		<!--<span class="current">-->
      			<?php
      				if ($i==$page) {
      				?>
      				<!--<span  class="current">-->
      					<a class="current" href="?page=<?php echo $i;?>&keyword=<?php echo $keyword;?>"><?php echo $i;?></a>
      				<!--</span>-->
     			<?php  }else {  ?>
     		   <a href="?page=<?php echo $i;?>&keyword=<?php echo $keyword;?>"><?php echo $i;?></a>
     		   <?php  }  ?>
   		<?php endfor;?>
   			
      	<a href="?page=<?php echo $next;?>&keyword=<?php echo $keyword;?>">下一页</a>
      	<a href="?page=<?php echo $countPage;?>&keyword=<?php echo $keyword;?>">尾页</a> 
      	</div>
      	
      	
      	  </td>
    </tr>
    	
     </div>  
     
    <p></p>  	
  
    <div class="panel admin-panel">
	<div class="panel-head"><strong class="icon-reorder">现场施工阶段</strong></div>
	<table class="table table-hover text-center">
    <tr>
      <th width="11%">入场时间</th>
      <th width="11%">堆场位置</th>
      <th width="11%">使用时间</th>
      <th width="11%">场内运输要求</th>
      <th width="11%">吊装要求</th>
      <th width="11%">安装方法</th>
      <th width="11%">连接节点及方法</th>
      <th width="11%">验收时间</th>
      <th width="12%">验收人员</th>
    </tr>
    
    
    	<?php?>

	<?php
	$sql = "select * from goujian where ma = '$keyword' or ming = '$keyword' limit {$limitFrom}, {$limitNews}";
	$result = mysqli_query($link, $sql);  
    if ($result) {
     		while($row=mysqli_fetch_array($result)) {
//	while ($row=mysqli_fetch_array($result1,MYSQLI_ASSOC)){
	?>   
   	<tr style="font-size: 15px;" >
      <td><?php echo $row['ruchang'];?></td>         
      <td><?php echo $row['duifang'];?></td>
      <td><?php echo $row['shiyong'];?></td>
      <td><?php echo $row['yunshu'];?></td>
      <td><?php echo $row['diaozhuang'];?></td>
      <td><?php echo $row['anzhuang'];?></td>
      <td><?php echo $row['jiedian'];?></td>
      <td><?php echo $row['yanshou'];?></td>
      <td>楼智博</td>
    </tr>

    <?php
    				}
    	}
    ?>
    
    </table>
    
 	<tr>
      <td colspan="8">
      	<div class="pagelist"> 
      		
      	<a href="?page=<?php echo $prev;?>&keyword=<?php echo $keyword;?>">上一页</a> 
      	
      	<?php for($i=1; $i<=$countPage; $i++):?>
      		<!--<span class="current">-->
      			<?php
      				if ($i==$page) {
      				?>
      				<!--<span  class="current">-->
      					<a class="current" href="?page=<?php echo $i;?>&keyword=<?php echo $keyword;?>"><?php echo $i;?></a>
      				<!--</span>-->
     			<?php  }else {  ?>
     		   <a href="?page=<?php echo $i;?>&keyword=<?php echo $keyword;?>"><?php echo $i;?></a>
     		   <?php  }  ?>
   		<?php endfor;?>
   			
      	<a href="?page=<?php echo $next;?>&keyword=<?php echo $keyword;?>">下一页</a>
      	<a href="?page=<?php echo $countPage;?>&keyword=<?php echo $keyword;?>">尾页</a> 
      	</div>
          	  </td>
    </tr>
    </div>
    
     <p></p>  	
    
    <div class="panel admin-panel">
	<div class="panel-head"><strong class="icon-reorder">运维阶段</strong></div>
	<table class="table table-hover text-center">
    <tr>
      <th width="11%">项目号</th>
      <th width="11%">项目类别</th>
      <th width="11%">构件所在楼层</th>
      <th width="11%">构件安装位置</th>
      <th width="11%">安装单位</th>
      <th width="11%">投产日期</th>
      <th width="11%">使用年限</th>
      <th width="11%">维修期</th>
      <th width="13%">维修单位</th>
    </tr>
    <!--</table>-->
    	<?php?>

	<?php
    $sql = "select * from goujian where ma = '$keyword' or ming = '$keyword' limit {$limitFrom}, {$limitNews}";
	$result = mysqli_query($link, $sql); 
    if ($result) {
     		while($row=mysqli_fetch_array($result)) {
//	while ($row=mysqli_fetch_array($result1,MYSQLI_ASSOC)){
	?>   
   	<tr style="font-size: 15px;">
      <!--<td style="text-align: center;"><?php echo $row['hao'];?></td>--> 
      <td><?php echo $row['hao'];?></td>        
      <td><?php echo $row['leibie'];?></td>
      <td><?php echo $row['louceng'];?></td>
      <td><?php echo $row['weizhi'];?></td>
      <td><?php echo $row['danwei'];?></td>
      <td><?php echo $row['touchan'];?></td>
      <td><?php echo $row['nianxian'];?></td>
      <td>1年</td>
      <td><?php echo $row['weixiudanwei'];?></td>
    </tr>

    <?php
    				}
    	}
    ?>
    
    </table>
    
 	<tr>
      <td colspan="8">
      	<div class="pagelist"> 
      		
      	<a href="?page=<?php echo $prev;?>&keyword=<?php echo $keyword;?>">上一页</a> 
      	
      	<?php for($i=1; $i<=$countPage; $i++):?>
      		<!--<span class="current">-->
      			<?php
      				if ($i==$page) {
      				?>
      				<!--<span  class="current">-->
      					<a class="current" href="?page=<?php echo $i;?>&keyword=<?php echo $keyword;?>"><?php echo $i;?></a>
      				<!--</span>-->
     			<?php  }else {  ?>
     		   <a href="?page=<?php echo $i;?>&keyword=<?php echo $keyword;?>"><?php echo $i;?></a>
     		   <?php  }  ?>
   		<?php endfor;?>
   			
      	<a href="?page=<?php echo $next;?>&keyword=<?php echo $keyword;?>">下一页</a>
      	<a href="?page=<?php echo $countPage;?>&keyword=<?php echo $keyword;?>">尾页</a> 
      	</div>
          	  </td>
    </tr>
    	
    <a href="MNIST_data.zip">下载</a>

</div>

<script type="text/javascript">
function del(id,mid){
	if(confirm("您确定要删除吗?")){
	
	}
}
</script>

</body>
</html>