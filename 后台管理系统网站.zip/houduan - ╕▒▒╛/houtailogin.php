<?php
	
	$name = isset($_POST['name']) ? $_POST['name'] : ""; 
	$password = isset($_POST['password']) ? $_POST['password'] : ""; 
//	echo $name; 
echo "<script> alert('登录成功');window.location.href='index.html'</script>";
?>