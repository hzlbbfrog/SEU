<?php
	header("content-type:text/html;charset=utf8");
	$link =mysqli_connect('localhost:3306','root','localhost','news');
	if (!$link) die("连接失败");
	mysqli_set_charset($link, "utf8"); 
	
	$result1 = mysqli_query($link, 'SELECT * FROM yanxue');
// 	$arr1=mysqli_fetch_all($result1,MYSQLI_ASSOC);//从结果集中取得所有行作为关联数组：
   	// mysql_fetch_array()函数从结果集中取得一行作为关联数组，或数字数组，或二者兼有
   	
   	// echo 可以内置html标签。HTML标签里也可以内置PHP。
   	
//	print_r($arr1);
// 	$id=1;
// 	$arr2=json_encode($arr1,JSON_UNESCAPED_UNICODE);
// 	echo "<script> arr=$arr2;
// 		  </script>";
//	echo $arr2; 
  	mysqli_close($link);	
?>

<!DOCTYPE html>
<html lang="zh-cn">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta name="renderer" content="webkit">
<title></title>
<link rel="stylesheet" href="css/pintuer.css">
<link rel="stylesheet" href="css/admin.css">
	<link href="umeditorphp/themes/default/css/umeditor.css" type="text/css" rel="stylesheet">
	
	<script type="text/javascript" src="umeditorphp/third-party/jquery.min.js"></script>
    <script type="text/javascript" charset="utf-8" src="umeditorphp/umeditor.config.js"></script>
    <script type="text/javascript" charset="utf-8" src="umeditorphp/umeditor.min.js"></script>
    <script type="text/javascript" charset="utf-8" src="umeditorphp/umeditor.js"></script>
    <script type="text/javascript" src="umeditorphp/lang/zh-cn/zh-cn.js"></script>
<!--<script src="js/jquery.js"></script>-->
<script src="js/pintuer.js"></script>
</head>

<body>
<div class="panel admin-panel">
  <div class="panel-head"><strong class="icon-reorder"> 内容列表</strong></div>
  <div class="padding border-bottom">  
  <button type="button" class="button border-yellow" onclick="window.location.href='#add'"><span class="icon-plus-square-o"></span> 添加内容</button>
  </div>
  <table class="table table-hover text-center">
    <tr>
      <th width="10%">ID</th>
      <th width="20%">图片</th>
      <th width="15%">名称</th>
      <th width="5%">作者</th>
      <th width="20%">日期</th>
      <th width="5%">是否有文章</th>
      <th width="15%">操作</th>
    </tr>
	<?php?>
	<?php
	while ($row=mysqli_fetch_array($result1,MYSQLI_ASSOC)){
	?>   
   	<tr>
      <td><?php echo $row['id'];?></td>     
      <td><img src="<?php echo "maps/".$row['url']?>" alt="" width="120" height="50" /></td>
      <!--<td><?php echo $row['url'];?></td>-->
      <!--<td><img src="maps/111.gif" alt="" width="120" height="50" /></td>-->
      
      <td><?php echo $row['title'];?></td>
      <td><?php echo $row['author'];?></td>
      <!--<td><?php echo htmlspecialchars_decode($row['content']);?></td>-->
       <!--<td><?php echo $row['content'];?></td>-->
      <td><?php echo $row['date'];?></td>
      <td><?php echo $row['flag'];?></td>
      <td><div class="button-group">
      <a class="button border-main" href="#add"><span class="icon-edit"></span> 修改</a>
      <a class="button border-red" href="javascript:void(0)" onclick="return del(1,1)"><span class="icon-trash-o"></span> 删除</a>
      </div></td>
    </tr>
    
    <?php
    }
    ?>

  </table>
</div>

<script type="text/javascript">
function del(id,mid){
	if(confirm("您确定要删除吗?")){
	
	}
}
</script>

<div class="panel admin-panel margin-top" id="add">
  <div class="panel-head"><strong><span class="icon-pencil-square-o"></span> 增加内容</strong></div>
  <div class="body-content">
    <form method="post" class="form-x" action="yanxuep.php">     
      <div class="form-group">
        <div class="label">
          <label>标题：</label>
        </div>
        <div class="field">
          <input type="text" class="input w50" value="" name="title" data-validate="required:请输入标题" />
          <div class="tips"></div>
        </div>
      </div>
      <div class="form-group">
        <div class="label">
          <label>作者：</label>
        </div>
        <div class="field">
          <input type="text" class="input w50" value="" name="author" data-validate="required:请输入作者名" />
          <div class="tips"></div>
        </div>
      </div>
      <div class="form-group">
        <div class="label">
          <label>日期</label>
        </div>
        <div class="field">
          <input type="text" class="input w50" name="date" value=""  />
          <div class="tips"></div>
        </div>
      </div>
      
      <div class="form-group">
        <div class="label">
          <label>URL：</label>
        </div>
        <div class="field">
          <input type="text" class="input w50" name="url" value=""  />
          <div class="tips"></div>
        </div>
      </div>
      
       <div class="form-group">
      	<div class="label">
      		 <label>图片：</label>
		</div>
		<script>
		</script>
		<div class="field">
			<script id="map" name="map" type="text/plain" style="width:800px;height:200px;">
       	 	  这里上传你的图片
   	  		</script>
		</div>
      </div>
      
      <div class="form-group">
        <div class="label">
          <label>是否有文章</label>
        </div>
        <div class="field">
          <input type="text" class="input w50" name="flag" value=""  />
          <div class="tips"></div>
        </div>
      </div>
      
      <div class="form-group">
      	<div class="label">
      		 <label>正文：</label>
		</div>
		<script>
		</script>
		
		<div class="field">
			<script id="myEditor" name="myEditor" type="text/plain" style="width:800px;height:200px;">
       	 	  这里写你的初始化内容 
   	  		 </script>
		</div>
      		 
      </div>
      
       <script type="text/javascript">
      var um = UM.getEditor('map');
      </script>
      
      <script type="text/javascript">
      var um = UM.getEditor('myEditor');
      </script>
      <div class="form-group">
        <div class="label">
          <label></label>
        </div>
        <div class="field">
          <button class="button bg-main icon-check-square-o" type="submit"> 提交</button>
        </div>
      </div>
    </form>
  </div>
</div>
</body>
</html>