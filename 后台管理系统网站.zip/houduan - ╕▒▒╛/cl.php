<?php

header("content-type:text/html;charset=utf-8");
$id=$_GET['id'];
$conn=mysqli_connect("localhost","root","root","news"); 
$flag=1;
if($conn){
    $sql="update jiequ set flag='$flag' where id ='$id' ";
	$result=mysqli_query($conn,$sql);
    if($result){
        echo"<script>alert('受理成功！');location.href='chuli.php';</script>";
    }else{
//    echo "<script>alert('受理失败！');location='" . $_SERVER['HTTP_REFERER'] . "'</script>";
        exit;
    }
}die("数据库连接失败" .mysqli_connect_error());
	
?>